<?
$opened = $db->numRows($db->query("SELECT id FROM deposits WHERE status=?i",0));
$closed = $db->numRows($db->query("SELECT id FROM deposits WHERE status=?i",1));
$users = $db->numRows($db->query("SELECT id FROM ss_users"));

if($balance_ == true){
	require_once('core/classes/cpayeer.php');
	$payeer = new CPayeer($accountNumber, $apiId, $apiKey);
	if($payeer->isAuth()){
		$balance = $payeer->getBalance();
		$balance = $balance["balance"]["RUB"]["DOSTUPNO"] . ' <i class="fas fa-ruble-sign"></i>';
	}else{
		$balance = '<font color="red">ERROR</font>';
	}
}else{
	$balance = $db->fetch($db->query("SELECT SUM(summa) AS summa FROM deposits WHERE status=?i",0));
}
?>
<html>
<head>
	<title>Инвестиции | <?=$sitename;?></title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="msapplication-TileColor" content="#ffffff">
	<meta name="theme-color" content="#ffffff">

	<link rel="shortcut icon" href="favicon.png">

	<link href="//fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Roboto" rel="stylesheet">

	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
	<link href="/media/css/alertify.core.css" rel="stylesheet">
	<link href="/media/css/alertify.default.css" rel="stylesheet">
	<link href="/media/css/custom.css" rel="stylesheet">
	<link href="/media/css/flag-icon.min.css" rel="stylesheet">
	<link href="/media/css/sweetalert.min.css" rel="stylesheet">

	<link rel="stylesheet" href="/media/font-awesome/font-awesome.css">
	<script type="text/javascript" src="/media/js/jquery-1.7.2.js"></script>
	<link rel="stylesheet" href="/media/css/main.css">

	<script src="//code.jquery.com/jquery-3.2.1.min.js"></script>
	<script src="/media/js/sweetalert.min.js"></script>
	<style>.cf-hidden { display: none; } .cf-invisible { visibility: hidden; }</style>


</head>
<body>

	<?
	$ihr = $db->getOne("SELECT i_have_refs_as_curator FROM ss_users WHERE id=?i",$id);

	$refsprofit = $db->query("SELECT SUM(summa) as payed FROM deposits WHERE curatorid=?i",$id);
	$refsprofit = $db->fetch($refsprofit);
	$payed = $refsprofit['payed']*($refpercent/100);

	$refsprofit = $db->query("SELECT SUM(summa) as waited FROM deposits WHERE status=?i AND curatorid=?i",0,$id);
	$refsprofit = $db->fetch($refsprofit);
	$waited = $refsprofit['waited']*($refpercent/100);
	?>

    <?
    $closed=$db->fetch($db->query("SELECT SUM(summa) AS Summa FROM deposits WHERE status=?i",2));
    $Users=$db->numRows($db->query("SELECT id FROM ss_users"));
    $opened=$db->fetch($db->query("SELECT SUM(summa) AS Summa FROM deposits WHERE status=?i",1));
    ?>
	<nav class="navbar navbar-fixed-top navbar-inverse">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand hidden-sm hidden-xs" href="/"><?=$sitename;?> </a>
			</div>
			<div id="navbar" class="collapse navbar-collapse">
				<ul class="nav navbar-nav">
					<li class=""><a href="/">Главная</a></li>
					<li class=""><a href="/?page=about">О нас</a></li>
					<li class=""><a href="/?page=rules">Соглашение</a></li>
					<li class=""><a href="/?page=faq">FAQ</a></li>
					<li class=""><a href="https://vk.com/hashbet.club">Вконтакте</a></li>
					<li><a href="/?page=contacts">Контакты</a></li>
					<?if(empty($id)){?>

					<?}else{?>
						<li class=""><a href="/?page=exit">Выход</a></li>
					<?}?>
				</ul>
			</div>
		</div>
	</nav>

<div class="green">
	<div class="container padding-container">
		<div class="panel">
			<div class="logo-in center-block hidden-sm hidden-xs red"><img src="/media/svg/logo.svg" alt="<?=$sitename;?>" height="100" width="100"/><?=$sitename;?></div>
				<div class="center-block text-center" id="pay_block">
					<h2 class="text-center">+50% к вашему вкладу Payeer за 24 часа</h2>
					<?if(empty($id)){?>
						<form action="" method="post" class="center-block form-inline">
							<input type="hidden" name="do" value="toaccount">
							<input type="hidden" name="antipovtor" value="<?=time();?>">
							<div class="form-group">
								<input name="wallet" required class="form-control big-input" placeholder="Кошелёк PAYEER"/>
							</div>
							<button class="btn btn-oldstyle big-btn" type="submit">Авторизация</button>
						</form>
					<?}else{?>
						<form action="" method="post" class="center-block form-inline">
							<input type="hidden" name="do" value="payeer_pay">
							<input type="hidden" name="antipovtor" value="<?=time();?>">
							<p>Минимальная сумма вклада - 10.00 <i class="fas fa-ruble-sign"></i>, максимальная сумма вклада - 10000.00 <i class="fas fa-ruble-sign"></i></p>

							<div class="form-group">
								<input name="m_amount" required class="form-control big-input" placeholder="Введите сумму"/>
							</div>
							<button class="btn btn-oldstyle big-btn" type="submit">Пополнить</button>
						</form>
                        <form action="" method="post" class="center-block form-inline">
                            <input type="hidden" name="do" value="payeer_pay">
                            <input type="hidden" name="antipovtor" value="<?=time();?>">
                            <div class="form-group">
                                <input name="m_amount" required class="form-control big-input" placeholder="Введите сумму"/>
                            </div>
                            <button class="btn btn-oldstyle big-btn" type="submit">Выплатить</button>
                        </form>
						<br>
						<p>
						Ваша <?=$refpercent;?>% реф ссылка:
						<input class="form-control ref_input" value=" <?=$http_s?>://<?=$host?>/?ref=<?=$id?>" onClick="select()" size="30" type="text">
						<p> Заработано на реф. программе - <font style="font-weight:bold;">
								<?=$payed?>
							 <i class="fas fa-ruble-sign"></i></font> </p>
						</p>

                        <p> Заработано на депозитах - <font style="font-weight:bold;">
                                <?$total_sum=$db->fetch($db->query("SELECT SUM(summa) AS Summa FROM deposits WHERE status=?i AND userid=?i",2,$id));
                                ?>
                                <?=$total_sum['Summa']+($total_sum['Summa']*($percent_u/100));?>
                                <i class="fas fa-ruble-sign"></i></font> </p>
                        </p>
					<?}?>
				</div>
			</div>
		</div>
	</div>

<div class="container">
	<div class="row">
		<div class="col-xs-12">
			<div class="text-center project-info ">
			<div class="row ">
			<div class="bl-stat col-sm-3 col-xs-6" id="frist_pay--off" style="24.333333% !important">
			<h3 class="currency">24-04-2018</h3> <span class="text-muted">Старт проекта</span>
			</div>
			<div class="bl-stat col-sm-3 col-xs-6" id="frist_pay--off" style="24.333333% !important">
			<h3 class="currency"><i class="fas fa-ruble-sign"></i> <?=$opened['Summa']?></h3> <span class="text-muted">Всего пополнено</span>
			</div>
			<div class="bl-stat col-sm-3 col-xs-6" id="all_fond" style="24.333333% !important">
                <?$uptimes =$_POST['uptimes'];?>

			<h3 class="currency"><i class="fas fa-ruble-sign"></i> <?=$closed['Summa']+($closed['Summa']*$percent_u/100)+$uptimes;?></h3><span class="text-muted">Всего выведено</span>
			</div>
			<div class="bl-stat col-sm-3 col-xs-6" id="all_referal_pay_out" style="24.333333% !important">
			<h3 class=""><i class="fa fa-user"></i> <?=$users;?></h3><span class="text-muted">Пользователей</span>
			</div>
			</div>
			</div>
