
</div>
</div>
</div>

<?if(!empty($_error)){?><div class="message" id="error"><?=$_error?></div><?}?>
<?if(!empty($_success)){?><div class="message" id="ok"><?=$_success?></div><?}?>

<footer class="footer">
<div class="container">
<div class="row">
<div class="col-sm-12">
<div class="links col-sm-4">
<h5><span>Copyright 2018 <i class="far fa-copyright"></i> Все права защищены</span></h5>
</div>


</div>
</div>
</div>
</footer>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	<script defer src="https://use.fontawesome.com/releases/v5.0.9/js/all.js" integrity="sha384-8iPTk2s/jMVj81dnzb/iFR2sdA7u06vHJyyLlAd4snFpCl/SnyUjRrbdJsw1pGIl" crossorigin="anonymous"></script>
<script>


    $(document).ready(function(){
        setInterval(function(){
            $('.countdown').each(function(){
                    var time=$(this).text().split(':');
                    var timestamp=time[0]*3600+ time[1]*60+ time[2]*1;timestamp-=timestamp>0;
                    var hours=Math.floor(timestamp/3600);
                    var minutes=Math.floor((timestamp- hours*3600)/ 60);
                    var seconds=timestamp- hours*3600- minutes*60;if(hours<10){hours='0'+ hours;}

                    if(minutes<10){minutes='0'+ minutes;}
                    if(seconds<10){seconds='0'+ seconds;}
                    if(timestamp>0){
                        $(this).text(hours+':'+ minutes+':'+ seconds);
                    }else{
                        $(this).text('Выплачено');
                    }
                }
            );
            $(".profit").each(function(){
                var a=parseInt($(this).attr("data-tm"))+1;
                if(a<86400){
                    var b=a*$(this).attr("data-prc");
                    $(this).attr("data-tm",a);
                    $(this).html("<center>"+b.toFixed(5)+"&nbsp;руб.</center>")}})},1000);

    })


</script>
</body>
</html>
