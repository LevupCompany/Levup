<?
if(!defined('SCRIPT_BY_SIRGOFFAN')){
exit();
}
?>


 </div>
 
</div> 

</div></div>	



</div>


<script type="text/javascript" src="/<?=$templ_dir.'/'.$templ_name?>/js/plugins.js"></script>
<script type="text/javascript" src="/<?=$templ_dir.'/'.$templ_name?>/js/main-not-compiled.js"></script>
	
</body></html>
