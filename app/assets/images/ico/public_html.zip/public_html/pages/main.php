<style>
    th, td {
        text-align: center;
    }
</style>

<div class="panel panel-default user-window">
    <div class="panel-body">
        <ul class="nav nav-tabs" role="tablist">
            <? if(empty($id)){?>
            <li role="presentation">
                <a href="#all_deposits" role="tab" data-toggle="tab">Последние депозиты</a>
            </li>
            <li role="presentation">
                <a href="#pays" role="tab" data-toggle="tab">Последние выплаты </a>
            </li>
            <?}else{?>
            <li role="presentation">
                <a href="#all_deposits" role="tab" data-toggle="tab">Последние депозиты</a>
            </li>
            <li role="presentation">
                <a href="#pays" role="tab" data-toggle="tab">Последние выплаты </a>
            </li>
            <li role="presentation">
                <a href="#my_deposits" role="tab" data-toggle="tab">Мои депозиты</a>
            </li>
            <li role="presentation">
                <a href="#my_pays" role="tab" data-toggle="tab">Мои выплаты</a>
            </li>
            <li role="presentation">
                <a href="#my_refs" role="tab" data-toggle="tab">Мои рефералы</a>
            </li>
            <?}?>
        </ul>
        <div class="tab-content">
        <? if(empty($id)){?>
            <div role="tabpanel" class="tab-pane active" id="all_deposits">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                        <tr bgcolor="#000" height="30" style="text-transform: uppercase;text-shadow: 0 1px 1px #333;font-weight: bold;color:#FFFFFF;">
                            <th align="center" width="150px"><b>Дата вклада</b></th>
                            <th align="center" width="100px"><b>Кошелек</b></th>
                            <th align="center" width="100px"><b>Депозит</b></th>
                            <th align="center" width="100px"><b>Осталось</b></th>
                            <th align="center" width="100px"><b>На вывод</b></th>
                        </tr>
                        </thead>
                        <?
                        $checkdeps=$db->getOne("SELECT id FROM `deposits` WHERE status='1' LIMIT 1");
                        if($checkdeps > 0){
                            $depositsrow=$db->query("SELECT * FROM `deposits` WHERE status='1' ORDER BY id DESC LIMIT 50");
                            while($deposits=$db->fetch($depositsrow)){?>
                                <tr class="htt">
                                    <td align="center"> <?=date('d.m.Y H:i',$deposits['unixtime'])?></td>
                                    <?
                                    $wallet=substr($db->getOne("SELECT wallet FROM `ss_users` WHERE id=?i",$deposits['userid']), 0, -3);
                                    ?>
                                    <td align="center"> <b><?=$wallet?><font color="#FDA833">XXX</b></font></td>
                                    <td align="center"> <?=$deposits['summa']?> руб.</td>
                                    <?
                                    $seconds = time()-$deposits['unixtime'];
                                    if($seconds>(3600*$depperiod)){
                                        $deptime="Выплачено";
                                    }else{
                                        $hours = floor($seconds/3600);
                                        $seconds = $seconds-($hours*3600);
                                        $minutes = floor($seconds/60);
                                        $seconds = $seconds-($minutes*60);
                                        $seconds = floor($seconds);
                                        $h=$depperiod-($hours+1);
                                        if($h<10){$h='0'.$h;}
                                        $m=60-($minutes+1);
                                        if($m<10){$m='0'.$m;}
                                        $s=60-($seconds+1);
                                        if($s<10){$s='0'.$s;}
                                        $deptime=$h.":".$m.":".$s;
                                    }
                                    ?>
                                    <td class="countdown" align="center"><?=$deptime;?></td>
                                    <td align="center" name="deposit" > <?=$deposits['summa']+($deposits['summa']*($percent_u/100))?> руб.</td>
                                </tr>
                            <?}}else{?>
                        <?}?>
                    </table>
                </div>
            </div>
            <div role="tabpanel" class="tab-pane" id="pays">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                        <tr bgcolor="#000" height="30" style="text-transform: uppercase;text-shadow: 0 1px 1px #333;font-weight: bold;color:#FFFFFF;">
                            <th align="center" width="150px"><b>Дата вклада</b></th>
                            <th align="center" width="100px"><b>Кошелек</b></th>
                            <th align="center" width="100px"><b>Депозит</b></th>
                            <th align="center" width="100px"><b>Осталось</b></th>
                            <th align="center" width="100px"><b>На вывод</b></th>
                        </tr>
                        </thead>
                        <?
                        $checkdeps=$db->getOne("SELECT id FROM `deposits` WHERE status='2' LIMIT 1");
                        if($checkdeps > 0){
                            $depositsrow=$db->query("SELECT * FROM `deposits` WHERE status='2' ORDER BY id DESC LIMIT 50");
                            while($deposits=$db->fetch($depositsrow)){?>
                                <tr class="htt">
                                    <td align="center"> <?=date('d.m.Y H:i',$deposits['unixtime'])?></td>
                                    <?
                                    $wallet=substr($db->getOne("SELECT wallet FROM `ss_users` WHERE id=?i",$deposits['userid']), 0, -3);
                                    ?>
                                    <td align="center"> <b><?=$wallet?><font color="#FDA833">XXX</b></font></td>
                                    <td align="center"> <?=$deposits['summa']?> руб.</td>
                                    <?
                                    $seconds = time()-$deposits['unixtime'];
                                    if($seconds>(3600*$depperiod)){
                                        $deptime="Выплачено";
                                    }else{
                                        $hours = floor($seconds/3600);
                                        $seconds = $seconds-($hours*3600);
                                        $minutes = floor($seconds/60);
                                        $seconds = $seconds-($minutes*60);
                                        $seconds = floor($seconds);
                                        $h=$depperiod-($hours+1);
                                        if($h<10){$h='0'.$h;}
                                        $m=60-($minutes+1);
                                        if($m<10){$m='0'.$m;}
                                        $s=60-($seconds+1);
                                        if($s<10){$s='0'.$s;}
                                        $deptime=$h.":".$m.":".$s;
                                    }
                                    ?>
                                    <td class="countdown" align="center"><?=$deptime;?></td>
                                    <td align="center" name="deposit" > <?=$deposits['summa']+($deposits['summa']*($percent_u/100))?> руб.</td>
                                </tr>
                            <?}}else{?>
                            Нет вкладов
                        <?}?>
                    </table>
                </div>
            </div>
        <?}else{?>
            <div role="tabpanel" class="tab-pane active" id="all_deposits">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                        <tr bgcolor="#000" height="30" style="text-transform: uppercase;text-shadow: 0 1px 1px #333;font-weight: bold;color:#FFFFFF;">
                            <th align="center" width="150px"><b>Дата вклада</b></th>
                            <th align="center" width="100px"><b>Кошелек</b></th>
                            <th align="center" width="100px"><b>Депозит</b></th>
                            <th align="center" width="100px"><b>Осталось</b></th>
                            <th align="center" width="100px"><b>На вывод</b></th>
                        </tr>
                        </thead>
                        <?
                        $checkdeps=$db->getOne("SELECT id FROM `deposits` WHERE status='1' LIMIT 1");
                        if($checkdeps > 0){
                            $depositsrow=$db->query("SELECT * FROM `deposits` WHERE status='1' ORDER BY id DESC LIMIT 50");
                            while($deposits=$db->fetch($depositsrow)){?>
                                <tr class="htt">
                                    <td align="center"> <?=date('d.m.Y H:i',$deposits['unixtime'])?></td>
                                    <?
                                    $wallet=substr($db->getOne("SELECT wallet FROM `ss_users` WHERE id=?i",$deposits['userid']), 0, -3);
                                    ?>
                                    <td align="center"> <b><?=$wallet?><font color="#FDA833">XXX</b></font></td>
                                    <td align="center"> <?=$deposits['summa']?> руб.</td>
                                    <?
                                    $seconds = time()-$deposits['unixtime'];
                                    if($seconds>(3600*$depperiod)){
                                        $deptime="Выплачено";
                                    }else{
                                        $hours = floor($seconds/3600);
                                        $seconds = $seconds-($hours*3600);
                                        $minutes = floor($seconds/60);
                                        $seconds = $seconds-($minutes*60);
                                        $seconds = floor($seconds);
                                        $h=$depperiod-($hours+1);
                                        if($h<10){$h='0'.$h;}
                                        $m=60-($minutes+1);
                                        if($m<10){$m='0'.$m;}
                                        $s=60-($seconds+1);
                                        if($s<10){$s='0'.$s;}
                                        $deptime=$h.":".$m.":".$s;
                                    }
                                    ?>
                                    <td class="countdown" align="center"><?=$deptime;?></td>
                                    <td align="center" name="deposit" > <?=$deposits['summa']+($deposits['summa']*($percent_u/100))?> руб.</td>
                                </tr>
                            <?}}else{?>
                        <?}?>
                    </table>
                </div>
            </div>
            <div role="tabpanel" class="tab-pane" id="pays">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                        <tr bgcolor="#000" height="30" style="text-transform: uppercase;text-shadow: 0 1px 1px #333;font-weight: bold;color:#FFFFFF;">
                            <th align="center" width="150px"><b>Дата вклада</b></th>
                            <th align="center" width="100px"><b>Кошелек</b></th>
                            <th align="center" width="100px"><b>Депозит</b></th>
                            <th align="center" width="100px"><b>Осталось</b></th>
                            <th align="center" width="100px"><b>На вывод</b></th>
                        </tr>
                        </thead>
                        <?
                        $checkdeps=$db->getOne("SELECT id FROM `deposits` WHERE status='2' LIMIT 1");
                        if($checkdeps > 0){
                            $depositsrow=$db->query("SELECT * FROM `deposits` WHERE status='2' ORDER BY id DESC LIMIT 50");
                            while($deposits=$db->fetch($depositsrow)){?>
                                <tr class="htt">
                                    <td align="center"> <?=date('d.m.Y H:i',$deposits['unixtime'])?></td>
                                    <?
                                    $wallet=substr($db->getOne("SELECT wallet FROM `ss_users` WHERE id=?i",$deposits['userid']), 0, -3);
                                    ?>
                                    <td align="center"> <b><?=$wallet?><font color="#FDA833">XXX</b></font></td>
                                    <td align="center"> <?=$deposits['summa']?> руб.</td>
                                    <?
                                    $seconds = time()-$deposits['unixtime'];
                                    if($seconds>(3600*$depperiod)){
                                        $deptime="Выплачено";
                                    }else{
                                        $hours = floor($seconds/3600);
                                        $seconds = $seconds-($hours*3600);
                                        $minutes = floor($seconds/60);
                                        $seconds = $seconds-($minutes*60);
                                        $seconds = floor($seconds);
                                        $h=$depperiod-($hours+1);
                                        if($h<10){$h='0'.$h;}
                                        $m=60-($minutes+1);
                                        if($m<10){$m='0'.$m;}
                                        $s=60-($seconds+1);
                                        if($s<10){$s='0'.$s;}
                                        $deptime=$h.":".$m.":".$s;
                                    }
                                    ?>
                                    <td class="countdown" align="center"><?=$deptime;?></td>
                                    <td align="center" name="deposit" > <?=$deposits['summa']+($deposits['summa']*($percent_u/100))?> руб.</td>
                                </tr>
                            <?}}else{?>
                            Нет вкладов
                        <?}?>
                    </table>
                </div>
            </div>
            <div role="tabpanel" class="tab-pane" id="my_deposits">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                        <tr bgcolor="#000" height="30" style="text-transform: uppercase;text-shadow: 0 1px 1px #333;font-weight: bold;color:#FFFFFF;">
                            <th align="center" width="150px"><b>Дата вклада</b></th>
                            <th align="center" width="100px"><b>Кошелек</b></th>
                            <th align="center" width="100px"><b>Депозит</b></th>
                            <th align="center" width="100px"><b>Осталось</b></th>
                            <th align="center" width="100px"><b>На вывод</b></th>
                        </tr>
                        </thead>
                        <?
                        $checkdeps=$db->getOne("SELECT id FROM `deposits` WHERE status='1' AND userid='".$id."' LIMIT 1");
                        if($checkdeps > 0){
                            $depositsrow=$db->query("SELECT * FROM `deposits` WHERE status='1' AND userid='".$id."' ORDER BY id DESC LIMIT 10");
                            while($deposits=$db->fetch($depositsrow)){?>
                                <tr class="htt">
                                    <td align="center"> <?=date('d.m.Y H:i',$deposits['unixtime'])?></td>
                                    <?
                                    $wallet=substr($db->getOne("SELECT wallet FROM `ss_users` WHERE id=?s",$deposits['userid']), 0, -3);
                                    ?>
                                    <td align="center"> <b><?=$wallet?><font color="#FDA833">XXX</b></font></td>
                                    <td align="center"> <?=$deposits['summa']?> руб.</td>
                                    <?
                                    $seconds = time()-$deposits['unixtime'];
                                    if($seconds>(3600*$depperiod)){
                                        $deptime="Выплачено";
                                    }else{
                                        $hours = floor($seconds/3600);
                                        $seconds = $seconds-($hours*3600);
                                        $minutes = floor($seconds/60);
                                        $seconds = $seconds-($minutes*60);
                                        $seconds = floor($seconds);
                                        $h=$depperiod-($hours+1);
                                        if($h<10){$h='0'.$h;}
                                        $m=60-($minutes+1);
                                        if($m<10){$m='0'.$m;}
                                        $s=60-($seconds+1);
                                        if($s<10){$s='0'.$s;}
                                        $deptime=$h.":".$m.":".$s;
                                    }
                                    ?>
                                    <td class="countdown" align="center"><?=$deptime;?></td>
                                    <td align="center" name="deposit" > <?=$deposits['summa']+($deposits['summa']*($percent_u/100))?> руб.</td>
                                </tr>
                            <?}}else{?>
                        <?}?>
                    </table>

                </div>
            </div>
            <div role="tabpanel" class="tab-pane" id="my_pays">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                        <tr bgcolor="#000" height="30" style="text-transform: uppercase;text-shadow: 0 1px 1px #333;font-weight: bold;color:#FFFFFF;">
                            <th align="center" width="150px"><b>Дата вклада</b></th>
                            <th align="center" width="100px"><b>Кошелек</b></th>
                            <th align="center" width="100px"><b>Депозит</b></th>
                            <th align="center" width="100px"><b>Осталось</b></th>
                            <th align="center" width="100px"><b>На вывод</b></th>
                        </tr>
                        </thead>
                        <?
                        $checkdeps=$db->getOne("SELECT id FROM `deposits` WHERE status='2' AND userid='".$id."' LIMIT 1");
                        if($checkdeps > 0){
                            $depositsrow=$db->query("SELECT * FROM `deposits` WHERE status='2' AND userid='".$id."' ORDER BY id DESC LIMIT 10");
                            while($deposits=$db->fetch($depositsrow)){?>
                                <tr class="htt">
                                    <td align="center"> <?=date('d.m.Y H:i',$deposits['unixtime'])?></td>
                                    <?
                                    $wallet=substr($db->getOne("SELECT wallet FROM `ss_users` WHERE id=?s",$deposits['userid']), 0, -3);
                                    ?>
                                    <td align="center"> <b><?=$wallet?><font color="#FDA833">XXX</b></font></td>
                                    <td align="center"> <?=$deposits['summa']?> руб.</td>
                                    <?
                                    $seconds = time()-$deposits['unixtime'];
                                    if($seconds>(3600*$depperiod)){
                                        $deptime="Выплачено";
                                    }else{
                                        $hours = floor($seconds/3600);
                                        $seconds = $seconds-($hours*3600);
                                        $minutes = floor($seconds/60);
                                        $seconds = $seconds-($minutes*60);
                                        $seconds = floor($seconds);
                                        $h=$depperiod-($hours+1);
                                        if($h<10){$h='0'.$h;}
                                        $m=60-($minutes+1);
                                        if($m<10){$m='0'.$m;}
                                        $s=60-($seconds+1);
                                        if($s<10){$s='0'.$s;}
                                        $deptime=$h.":".$m.":".$s;
                                    }
                                    ?>
                                    <td class="countdown" align="center"><?=$deptime;?></td>
                                    <td align="center" name="deposit" > <?=$deposits['summa']+($deposits['summa']*($percent_u/100))?> руб.</td>
                                </tr>
                            <?}}else{?>
                        <?}?>
                    </table>

                </div>
            </div>
            <div role="tabpanel" class="tab-pane" id="my_refs">
                <div class="table-responsive">
                    <?
                    $ihr=$db->getOne("SELECT i_have_refs_as_curator FROM ss_users WHERE id=?i",$id);

                    $refsprofit=$db->query("SELECT SUM(summa) as payed FROM deposits WHERE curatorid=?i",$id);
                    $refsprofit=$db->fetch($refsprofit);
                    $payed=$refsprofit['payed']*($refpercent/100);

                    $refsprofit=$db->query("SELECT SUM(summa) as waited FROM deposits WHERE status=?i AND curatorid=?i",0,$id);
                    $refsprofit=$db->fetch($refsprofit);
                    $waited=$refsprofit['waited']*($refpercent/100);


                    ?>

                    <table class="table">
                        <tr bgcolor="#000" height="30" valign="middle" align="center" style="text-transform: uppercase;text-shadow: 0 1px 1px #333;font-weight: bold;color:#FFFFFF;">
                            <td align="Center"> Логин </td>
                            <td align="Center"> Дата регистрации </td>
                            <td align="Center"> Доход реферала </td>
                            <td align="Center"> Прибыль </td>
                        </tr>
                        <? if($ihr>0){
                            $myrefsrow=$db->query("SELECT * FROM ss_users WHERE curator=?i ORDER BY id DESC",$id);
                            while($myrefs=$db->fetch($myrefsrow)){?>
                                <tr class="htt">

                                    <?
                                    $myrefsi = $myrefs['wallet'];
                                    $walle=substr($myrefsi, 0, -3);?>

                                    <td align="center"> <b><?=$walle?><font color="#FDA833">XXX</b></font></td>
                                    <td align="center"><?=date('d.m.Y H:i:s',$myrefs['reg_unix'])?></td>
                                    <?
                                    $refprofit=$db->query("SELECT SUM(summa) as personalprofit FROM deposits WHERE userid=?i",$myrefs['id']);
                                    $refprofit=$db->fetch($refprofit);
                                    ?>
                                    <td align="center"><?=$refprofit['personalprofit']?></td>
                                    <td align="center"><?=($refprofit['personalprofit']*($refpercent/100))?></td>

                                </tr>
                            <?}}else{?>
                            <tr class="htt"><td align="center" colspan="3">У вас нет рефералов</td></tr>
                        <?}?>
                    </table>lk


                    </td></tr></tbody>
                    </table>

                </div>
            </div>

        <?}?>
        </div>
    </div>
</div>
