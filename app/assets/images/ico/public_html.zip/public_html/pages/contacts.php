<h1 class="title">Контактная информация <?=$sitename;?></h1>
<div class="text">
	<p style=" padding:0px 20px 20px 20px;">
		Ссылка на группу сайта <a href="https://vk.com/nashagruppa"><?=$sitename;?></a>в вк
		Вы можете создать свой PAYEER кошелёк по <a href="https://payeer.com/" target = "_blank">этой ссылке</a>.
	</p>
</div>